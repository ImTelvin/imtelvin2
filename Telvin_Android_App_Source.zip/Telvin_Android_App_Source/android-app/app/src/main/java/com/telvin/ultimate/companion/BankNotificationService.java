package com.telvin.ultimate.companion;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BankNotificationService extends NotificationListenerService {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("ubb_companion", MODE_PRIVATE);
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        String combined = (title == null ? "" : title.toString() + " ") + (text == null ? "" : text.toString());
        if (!BankSmsReceiver.looksLikeDeposit(combined)) return;

        // Avoid forwarding the same notification repeatedly.
        String fingerprint = sha256(sbn.getPackageName() + "|" + combined);
        long now = System.currentTimeMillis();
        String previousHash = prefs.getString("last_notification_hash", "");
        long previousTime = prefs.getLong("last_notification_time", 0L);
        if (fingerprint.equals(previousHash) && now - previousTime < 120000L) return;
        prefs.edit().putString("last_notification_hash", fingerprint)
            .putLong("last_notification_time", now).apply();

        EXECUTOR.execute(() -> BankSmsReceiver.postToConfiguredEndpoints(this, "notif", combined));
    }

    private static String sha256(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format(java.util.Locale.ROOT, "%02x", b));
            return out.toString();
        } catch (Exception ignored) { return Integer.toHexString(value.hashCode()); }
    }
}
