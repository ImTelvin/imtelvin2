package com.telvin.ultimate.companion;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.URL;
import android.util.Base64;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ws.setSafeBrowsingEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"file".equals(uri.getScheme()) || !"android_asset".equals(uri.getHost());
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class AndroidBridge {
        @JavascriptInterface public boolean saveConfig(String endpointUrl, String token, String mode) {
            try {
                URL url = new URL(endpointUrl);
                String path = url.getPath() == null ? "" : url.getPath();
                boolean supportedEndpoint = path.contains("/autoconfirm/webhook") || path.endsWith("/payment/autoconfirm.php");
                if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost() == null ||
                    !supportedEndpoint || token == null || !token.matches("(?:ac_)?[A-Fa-f0-9]{40}")) return false;
                String safeMode = "builder".equals(mode) ? "builder" : "filtering";
                SharedPreferences prefs = getSharedPreferences("ubb_companion", MODE_PRIVATE);
                prefs.edit().putString(safeMode + "_endpoint_url", endpointUrl)
                    .putString(safeMode + "_auth_token", token)
                    .putString("active_mode", safeMode)
                    .apply();
                return true;
            } catch (Exception ignored) { return false; }
        }

        @JavascriptInterface public boolean configureFromSetupCode(String code) {
            try {
                String normalized = code.trim();
                while (normalized.length() % 4 != 0) normalized += "=";
                byte[] decoded = Base64.decode(normalized, Base64.URL_SAFE | Base64.NO_WRAP);
                JSONObject cfg = new JSONObject(new String(decoded, java.nio.charset.StandardCharsets.UTF_8));
                return saveConfig(cfg.optString("u", ""), cfg.optString("t", ""), cfg.optString("m", "filtering"));
            } catch (Exception ignored) { return false; }
        }

        @JavascriptInterface public void requestSmsPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, 101);
            }
        }

        @JavascriptInterface public void openNotificationSettings() {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }

        @JavascriptInterface public String getSavedConfig(String mode) {
            String safeMode = "builder".equals(mode) ? "builder" : "filtering";
            SharedPreferences prefs = getSharedPreferences("ubb_companion", MODE_PRIVATE);
            JSONObject saved = new JSONObject();
            try {
                saved.put("endpoint_url", prefs.getString(safeMode + "_endpoint_url", ""));
                saved.put("auth_token", prefs.getString(safeMode + "_auth_token", ""));
                saved.put("app_mode", safeMode);
            } catch (Exception ignored) { }
            return saved.toString();
        }

        @JavascriptInterface public void setActiveMode(String mode) {
            String safeMode = "builder".equals(mode) ? "builder" : "filtering";
            getSharedPreferences("ubb_companion", MODE_PRIVATE).edit().putString("active_mode", safeMode).apply();
        }

        @JavascriptInterface public String getConnectionStatus(String mode) {
            try {
                JSONObject saved = new JSONObject(getSavedConfig(mode));
                return saved.optString("endpoint_url", "").isEmpty() ? "disconnected" : "connected";
            } catch (Exception ignored) { return "disconnected"; }
        }
    }
}
