package com.telvin.ultimate.companion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.SmsMessage;
import android.provider.Telephony;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BankSmsReceiver extends BroadcastReceiver {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        StringBuilder body = new StringBuilder();
        try {
            SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
            if (messages != null) {
                for (SmsMessage message : messages) {
                    if (message != null && message.getMessageBody() != null) body.append(message.getMessageBody()).append(' ');
                }
            }
        } catch (Exception ignored) { return; }
        String text = body.toString().trim();
        if (!looksLikeDeposit(text)) return;

        PendingResult pending = goAsync();
        EXECUTOR.execute(() -> {
            try { postToConfiguredEndpoints(context, "sms", text); }
            finally { pending.finish(); }
        });
    }

    static boolean looksLikeDeposit(String text) {
        String t = text == null ? "" : text.toLowerCase(java.util.Locale.ROOT);
        boolean deposit = t.matches("(?s).*(واریز|دریافت|نشست|به حساب شما|deposit|credit).*");
        boolean otp = t.matches("(?s).*(رمز پویا|رمز یکبار|کد تایید|کد تأیید|otp|cvv2|password).*");
        boolean withdrawalOnly = t.matches("(?s).*(برداشت|خرید|کسر|پرداخت|withdraw|debit).*") &&
            !t.matches("(?s).*(واریز|نشست|deposit|credit).*");
        return deposit && !otp && !withdrawalOnly && t.matches("(?s).*\\d{4,}.*");
    }


    public static void postToConfiguredEndpoints(Context context, String source, String text) {
        SharedPreferences prefs = context.getSharedPreferences("ubb_companion", Context.MODE_PRIVATE);
        String mode = prefs.getString("active_mode", "filtering");
        String endpoint = prefs.getString(mode + "_endpoint_url", "");
        String token = prefs.getString(mode + "_auth_token", "");
        if (!endpoint.isEmpty() && !token.isEmpty()) postToBotEndpoint(endpoint, token, source, text);
    }

    public static void postToBotEndpoint(String endpoint, String token, String source, String text) {
        java.net.HttpURLConnection connection = null;
        try {
            java.net.URL url = new java.net.URL(endpoint);
            if (!"https".equalsIgnoreCase(url.getProtocol())) return;
            connection = (java.net.HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + token);
            connection.setDoOutput(true);
            org.json.JSONObject payload = new org.json.JSONObject();
            payload.put("source", source);
            payload.put("device", "Android-Companion");
            payload.put("text", text);
            try (java.io.OutputStream output = connection.getOutputStream()) {
                output.write(payload.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            int status = connection.getResponseCode();
            java.io.InputStream stream = status >= 200 && status < 400 ? connection.getInputStream() : connection.getErrorStream();
            if (stream != null) stream.close();
        } catch (Exception ignored) {
            // Never log or expose bank message content or device credentials.
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
