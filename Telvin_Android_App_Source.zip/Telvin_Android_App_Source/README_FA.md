# سورس اپ اندروید همراه

این پروژه مستقل از سورس ربات‌ساز است و کد اپ Android Companion را در پوشه `android-app/` دارد.

## ساخت APK
1. محتویات ZIP را در یک مخزن GitHub بارگذاری کنید.
2. از تب Actions، گردش‌کار `Build Android Companion APK` را اجرا کنید.
3. پس از موفقیت، Artifact با نام `telvin-companion-debug-apk` را دریافت کنید.

این محیط فاقد Android SDK و Gradle اجرایی نیست؛ بنابراین APK در همین اجرا کامپایل نشده است. Workflow برای ساخت APK در GitHub Actions آماده شده است.

اپ برای اتصال به endpoint امن HTTPS طراحی شده است. Setup Code را فقط از پنل خودتان بگیرید. پیامک بانکی به‌تنهایی اثبات قطعی پرداخت نیست.
